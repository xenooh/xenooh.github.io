import React from 'react'

const RepoDetail = () => {
  return (
    <div>RepoDetail</div>
  )
}

export default RepoDetail